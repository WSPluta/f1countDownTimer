var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
define(["require", "exports", "preact/jsx-runtime", "../counter/index", "../time/index", "preact/hooks", "ojs/ojmutablearraydataprovider", "ojs/ojkeyset", "ojs/ojasyncvalidator-regexp", "ojs/ojdrawerpopup", "ojs/ojbutton", "ojs/ojswitch", "ojs/ojformlayout", "ojs/ojinputtext", "ojs/ojlistview"], function (require, exports, jsx_runtime_1, index_1, index_2, hooks_1, MutableArrayDataProvider, ojkeyset_1, AsyncRegExpValidator) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Content = void 0;
    let eventData = [];
    const sortEvents = (events) => {
        let data = events.sort((a, b) => {
            if (a.startTime < b.startTime)
                return -1;
        });
        return data;
    };
    if (localStorage.length > 0) {
        for (let event in localStorage) {
            let val = localStorage.getItem(event);
            if (typeof val === "string")
                eventData.push({ name: event, startTime: val });
        }
        eventData = sortEvents(eventData);
    }
    const getCleanEventName = (name) => {
        let parts = name.split("-");
        return parts[0];
    };
    const validators = [
        new AsyncRegExpValidator({
            pattern: "[a-zA-Z0-9_ ]{0,}[^-]",
            hint: "can not contain a hyphen (-)",
            messageDetail: "Enter name without hyphen (-)",
        }),
    ];
    function Content() {
        const eventDP = (0, hooks_1.useRef)(new MutableArrayDataProvider(eventData, {
            implicitSort: [{ attribute: "startTime", direction: "ascending" }],
            keyAttributes: "index",
        }));
        const [eventTime, setEventTime] = (0, hooks_1.useState)(new Date("2022-12-25 00:00:00"));
        const [name, setName] = (0, hooks_1.useState)("No Event");
        const [realName, setRealName] = (0, hooks_1.useState)("");
        const [endOpened, setEndOpened] = (0, hooks_1.useState)(false);
        const [selectedEvent, setSelectedEvent] = (0, hooks_1.useState)(null);
        const [locale, setLocale] = (0, hooks_1.useState)(false);
        const [autoLoad, setAutoLoad] = (0, hooks_1.useState)(true);
        const [eventNameVal, setEventNameVal] = (0, hooks_1.useState)("");
        const [startTimeVal, setStartTimeVal] = (0, hooks_1.useState)("");
        const [scheduleValue, setScheduleValue] = (0, hooks_1.useState)("");
        const importSchedule = () => {
            let newSchedule = JSON.parse(scheduleValue);
            let count = 0;
            for (let event in newSchedule) {
                newSchedule[event].name = newSchedule[event].name + "-" + count;
                localStorage.setItem(newSchedule[event].name, newSchedule[event].startTime);
                count++;
            }
            newSchedule = sortEvents(newSchedule);
            eventDP.current.data = newSchedule;
        };
        const updateNameVal = (event) => {
            setEventNameVal(event.detail.value);
        };
        const updateStartTimeVal = (event) => {
            setStartTimeVal(event.detail.value);
        };
        const addEvent = () => {
            let tempName = eventNameVal;
            let tempStart = startTimeVal;
            let tempArray = [...eventDP.current.data];
            let startParts = tempStart.split(" ");
            let finalStart = startParts.toString().replace(",", "T");
            tempName = tempName += "-" + tempArray.length + 1;
            console.log("name: " + tempName + " : " + finalStart);
            tempArray.push({ name: tempName, startTime: finalStart });
            localStorage.setItem(tempName, finalStart);
            tempArray = sortEvents(tempArray);
            eventDP.current.data = tempArray;
        };
        const [timeNow, setTimeNow] = (0, hooks_1.useState)(new Date());
        (0, hooks_1.useEffect)(() => {
            let timer = setInterval(() => setTimeNow(new Date()), 1000);
            return () => clearInterval(timer);
        }, []);
        const endToggle = () => {
            endOpened ? setEndOpened(false) : setEndOpened(true);
        };
        const open = () => {
            setEndOpened(true);
        };
        const formatDate = (0, hooks_1.useCallback)((data) => {
            let dateObj = new Date(data);
            let options = {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: false,
            };
            return dateObj.toLocaleString(locale ? navigator.language : "en-US", options);
        }, []);
        const updateLocale = (event) => {
            setLocale(event.detail.value);
        };
        const selectedChangedHandler = (0, hooks_1.useCallback)((event) => {
            console.log("Selected: ", event.detail.value);
            if (event.detail.updatedFrom === "internal") {
                setSelectedEvent(event.detail.value);
            }
        }, [selectedEvent]);
        const updateScheduleVal = (event) => {
            setScheduleValue(event.detail.value);
        };
        const updateAutoLoad = (event) => {
            setAutoLoad(event.detail.value);
        };
        const loadNextScheduleItem = () => __awaiter(this, void 0, void 0, function* () {
            let idx = yield eventDP.current.data.findIndex((item) => item.name === realName);
            let data = yield eventDP.current.fetchByOffset({
                offset: 0,
            });
            if (idx + 1 < eventDP.current.data.length) {
                let newKey = data.results[idx + 1].metadata.key;
                setSelectedEvent(new ojkeyset_1.KeySetImpl([newKey]));
            }
            else {
                setAutoLoad(false);
                setSelectedEvent(new ojkeyset_1.KeySetImpl([]));
            }
        });
        (0, hooks_1.useEffect)(() => {
            if (selectedEvent) {
                let key = Array.from(selectedEvent.keys.keys.values());
                if (key.length > 0) {
                    let data = eventDP.current
                        .fetchByKeys({
                        keys: selectedEvent.values(),
                    })
                        .then((fetchResult) => {
                        const iterator = fetchResult.results.values();
                        const results = Array.from(iterator);
                        console.log("data: " + results[0].data);
                        setRealName(results[0].data.name);
                        setName(getCleanEventName(results[0].data.name));
                        setEventTime(new Date(results[0].data.startTime));
                    });
                }
                else {
                    setRealName("No Event");
                    setName("No Event");
                    setEventTime(new Date("2022-12-25 00:00:00"));
                }
            }
        }, [selectedEvent]);
        const deleteEvent = (event) => {
            let tempArray = [];
            let removedEvent = event.target.id;
            eventDP.current.data.filter((event) => {
                if (event.name !== removedEvent) {
                    tempArray.push({ name: event.name, startTime: event.startTime });
                }
            });
            if (tempArray.length === 0) {
                setRealName("No Event");
                setName("No Event");
                setEventTime(new Date("2022-12-25 00:00:00"));
                setSelectedEvent(new ojkeyset_1.KeySetImpl([]));
            }
            else {
                loadNextScheduleItem();
            }
            eventDP.current.data = tempArray;
            localStorage.removeItem(event.target.id);
        };
        const listItemTemplate = (0, hooks_1.useCallback)((event) => {
            return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar-start oj-flex oj-sm-flex-direction-column" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-typography-subheading-sm " }, { children: getCleanEventName(event.data.name) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: formatDate(event.data.startTime) }))] })), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ display: "icons", id: event.data.name, onojAction: deleteEvent, label: "Remove", class: "oj-flex-bar-end", "data-oj-clickthrough": "disabled" }, { children: (0, jsx_runtime_1.jsx)("span", { slot: "startIcon", class: "oj-ux-ico-close" }) }))] })));
        }, []);
        const noDataTemplate = (0, hooks_1.useCallback)(() => {
            return ((0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("h3", { children: "No Events available" }), (0, jsx_runtime_1.jsx)("div", { children: "Add an individual event, or import a full schedule below." })] }));
        }, []);
        const listAreaRef = (0, hooks_1.useRef)(null);
        const drawerPopupRef = (0, hooks_1.useRef)(null);
        (0, hooks_1.useEffect)(() => {
            const handleClickOutside = (event) => {
                if (listAreaRef.current &&
                    !listAreaRef.current.contains(event.target) &&
                    drawerPopupRef.current &&
                    !drawerPopupRef.current.contains(event.target) &&
                    endOpened) {
                    setEndOpened(false);
                }
            };
            document.addEventListener("mousedown", handleClickOutside);
            return () => {
                document.removeEventListener("mousedown", handleClickOutside);
            };
        }, [endOpened]);
        return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-flex-direction-row oj-sm-12 orbr-content-container" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-flex oj-sm-flex-direction-column oj-sm-4 oj-sm-margin-2x-left orbr-event-panel" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-align-items-center" }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-flex oj-flex-item oj-icon orbr-tag-icon oj-sm-align-items-centre", title: "Tag Heuer logo", alt: "Tag Heuer logo" }) })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center oj-typography-heading-md orbr-event-container" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-label" }, { children: "COUNTDOWN TO:" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-hero-label" }, { children: name })), (0, jsx_runtime_1.jsx)(index_1.Counter, { targetTime: eventTime, currentTime: timeNow, autoLoad: autoLoad, loadNext: loadNextScheduleItem }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-hero-label" }, { children: (0, jsx_runtime_1.jsx)(index_2.Time, { localTime: timeNow }) }))] }))] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-sm-9" }, { children: [(0, jsx_runtime_1.jsx)("div", { class: "oj-flex orbr-video-container" }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-typography-subheading-md oj-flex-bar oj-color-invert footer" }, { children: (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-end" }, { children: (0, jsx_runtime_1.jsx)("button", Object.assign({ class: "addbtn2", onClick: open }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-icon orbr-oracle-icon", title: "oracle logo", alt: "Oracle logo" }) })) })) }))] })), (0, jsx_runtime_1.jsx)("span", { children: (0, jsx_runtime_1.jsx)("oj-drawer-popup", Object.assign({ ref: drawerPopupRef, class: "orbr-drawer-end", edge: "end", opened: endOpened, autoDismiss: "none" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "orbr-drawer-container" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar orbr-drawer-header" }, { children: [(0, jsx_runtime_1.jsx)("h6", Object.assign({ class: "oj-flex-bar-start" }, { children: "Event Settings" })), (0, jsx_runtime_1.jsxs)("oj-button", Object.assign({ id: "endButtonCloser", display: "icons", chroming: "borderless", class: "oj-flex-bar-end", onojAction: endToggle }, { children: [(0, jsx_runtime_1.jsx)("span", { slot: "startIcon", class: "oj-ux-ico-close orbr-drawer-text-color" }), "Close"] }))] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "orbr-drawer-content" }, { children: [(0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-switch", { labelHint: "Use browser locale", labelEdge: "inside", value: locale, onvalueChanged: updateLocale }), (0, jsx_runtime_1.jsx)("oj-switch", { labelHint: "Auto-load schedule", labelEdge: "inside", value: autoLoad, onvalueChanged: updateAutoLoad })] }), (0, jsx_runtime_1.jsx)("h4", { children: "Select active event" }), (0, jsx_runtime_1.jsxs)("oj-list-view", Object.assign({ ref: listAreaRef, data: eventDP.current, selectionMode: "single", gridlines: { item: "visibleExceptLast" }, selected: selectedEvent, onselectedChanged: selectedChangedHandler, class: "orbr-listview-sizing" }, { children: [(0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: listItemTemplate }), (0, jsx_runtime_1.jsx)("template", { slot: "noData", render: noDataTemplate })] })), (0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ class: "oj-sm-margin-4x-top" }, { children: [(0, jsx_runtime_1.jsx)("h4", { children: "Add new event" }), (0, jsx_runtime_1.jsx)("oj-input-text", { labelHint: "Name", value: eventNameVal, clearIcon: "conditional", validators: validators, help: {
                                                            instruction: "Event names must not contain a dash (-)",
                                                        }, onvalueChanged: updateNameVal }), (0, jsx_runtime_1.jsx)("oj-input-text", { labelHint: "Start time", placeholder: "YYYY-MM-DD HH:MM:SS", help: {
                                                            instruction: "Required format YYYY-MM-DD<space>HH:MM:SS with one space.",
                                                        }, value: startTimeVal, clearIcon: "conditional", onvalueChanged: updateStartTimeVal }), (0, jsx_runtime_1.jsx)("oj-button", { onojAction: addEvent, label: "Add event" })] })), (0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ class: "oj-sm-margin-4x-top" }, { children: [(0, jsx_runtime_1.jsx)("h4", { children: "Import event schedule" }), (0, jsx_runtime_1.jsx)("oj-text-area", { rows: 10, labelHint: "Schedule", placeholder: '[ {"name": "My event", "startTime":"2023-03-19T14:15:00"} ]', value: scheduleValue, help: {
                                                            instruction: 'paste array of objects in the format of {"name":"my event", "startTime":"YYYY-MM-DDTHH:MM:SS"}',
                                                        }, onvalueChanged: updateScheduleVal }), (0, jsx_runtime_1.jsx)("oj-button", { onojAction: importSchedule, label: "Import" })] }))] }))] })) })) })] })) }));
    }
    exports.Content = Content;
});
