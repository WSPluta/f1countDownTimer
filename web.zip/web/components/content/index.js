define(["require", "exports", "preact/jsx-runtime", "../counter/index", "../time/index", "preact/hooks", "ojs/ojmutablearraydataprovider", "ojs/ojkeyset", "ojs/ojdrawerpopup", "ojs/ojbutton", "ojs/ojswitch", "ojs/ojformlayout", "ojs/ojinputtext", "ojs/ojlistview"], function (require, exports, jsx_runtime_1, index_1, index_2, hooks_1, MutableArrayDataProvider, ojkeyset_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Content = void 0;
    let eventData = [];
    if (localStorage.length > 0) {
        for (let event in localStorage) {
            let val = localStorage.getItem(event);
            if (typeof val === "string")
                eventData.push({ name: event, startTime: val });
        }
    }
    function Content() {
        const eventDP = (0, hooks_1.useRef)(new MutableArrayDataProvider(eventData));
        const [eventTime, setEventTime] = (0, hooks_1.useState)(new Date("2022-12-25 00:00:00"));
        const [name, setName] = (0, hooks_1.useState)("No Event");
        const [endOpened, setEndOpened] = (0, hooks_1.useState)(false);
        const [selectedEvent, setSelectedEvent] = (0, hooks_1.useState)(null);
        const [locale, setLocale] = (0, hooks_1.useState)(false);
        const [autoLoad, setAutoLoad] = (0, hooks_1.useState)(false);
        const [eventNameVal, setEventNameVal] = (0, hooks_1.useState)("");
        const [startTimeVal, setStartTimeVal] = (0, hooks_1.useState)("");
        const [scheduleValue, setScheduleValue] = (0, hooks_1.useState)("");
        const updateScheduleVal = (event) => {
            setScheduleValue(event.detail.value);
        };
        const updateAutoLoad = (event) => {
            setAutoLoad(event.detail.value);
        };
        const loadNextScheduleItem = () => {
            let currentKey = Array.from(selectedEvent.keys.keys.values());
            let newKey = currentKey[0] + 1;
            if (newKey < eventDP.current.data.length) {
                setSelectedEvent(new ojkeyset_1.KeySetImpl([newKey]));
            }
            else {
                setAutoLoad(false);
                setSelectedEvent(new ojkeyset_1.KeySetImpl([]));
            }
        };
        const importSchedule = () => {
            let newSchedule = JSON.parse(scheduleValue);
            for (let event in newSchedule) {
                localStorage.setItem(newSchedule[event].name, newSchedule[event].startTime);
            }
            eventDP.current.data = newSchedule;
        };
        const updateNameVal = (event) => {
            setEventNameVal(event.detail.value);
        };
        const updateStartTimeVal = (event) => {
            setStartTimeVal(event.detail.value);
        };
        const addEvent = () => {
            let tempName = eventNameVal;
            let tempStart = startTimeVal;
            let tempArray = [...eventDP.current.data];
            let exists = tempArray.find((event) => event.name === eventNameVal);
            if (!exists) {
                let startParts = tempStart.split(" ");
                let finalStart = startParts.toString().replace(",", "T");
                console.log("name: " + tempName + " : " + finalStart);
                tempArray.push({ name: tempName, startTime: finalStart });
                localStorage.setItem(tempName, finalStart);
                eventDP.current.data = tempArray;
            }
            else {
                alert("name already exists, please use a different event name.");
            }
        };
        const [timeNow, setTimeNow] = (0, hooks_1.useState)(new Date(Date.now()));
        const endToggle = () => {
            endOpened ? setEndOpened(false) : setEndOpened(true);
        };
        const open = () => {
            setEndOpened(true);
        };
        const formatDate = (data) => {
            let dateObj = new Date(data);
            let options = {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit",
                hour12: false,
            };
            return dateObj.toLocaleString(locale ? navigator.language : "en-US", options);
        };
        const updateLocale = (event) => {
            setLocale(event.detail.value);
        };
        const selectedChangedHandler = (0, hooks_1.useCallback)((event) => {
            console.log("Selected: ", event.detail.value);
            if (event.detail.updatedFrom === "internal") {
                setSelectedEvent(event.detail.value);
            }
        }, [selectedEvent]);
        (0, hooks_1.useEffect)(() => {
            if (selectedEvent) {
                let key = Array.from(selectedEvent.keys.keys.values());
                let tempData = [...eventDP.current.data];
                if (key.length > 0) {
                    let data = tempData[key[0]];
                    setName(data.name);
                    setEventTime(new Date(data.startTime));
                }
                else {
                    setName("No Event");
                    setEventTime(new Date("2022-12-25 00:00:00"));
                }
            }
        }, [selectedEvent]);
        const deleteEvent = (event) => {
            let removedEvent = event.target.id;
            let tempArray = [];
            eventDP.current.data.filter((event) => {
                if (event.name !== removedEvent) {
                    tempArray.push({ name: event.name, startTime: event.startTime });
                }
            });
            if (tempArray.length === 0) {
                setName("No Event");
                setEventTime(new Date("2022-12-25 00:00:00"));
                setSelectedEvent(null);
            }
            eventDP.current.data = tempArray;
            localStorage.removeItem(removedEvent);
        };
        const listItemTemplate = (event) => {
            return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar-start oj-flex oj-sm-flex-direction-column" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-typography-subheading-sm " }, { children: event.data.name })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: formatDate(event.data.startTime) }))] })), (0, jsx_runtime_1.jsx)("oj-button", Object.assign({ display: "icons", id: event.data.name, onojAction: deleteEvent, label: "Remove", class: "oj-flex-bar-end", "data-oj-clickthrough": "disabled" }, { children: (0, jsx_runtime_1.jsx)("span", { slot: "startIcon", class: "oj-ux-ico-close" }) }))] })));
        };
        const noDataTemplate = () => {
            return ((0, jsx_runtime_1.jsxs)("div", { children: [(0, jsx_runtime_1.jsx)("h3", { children: "No Events available" }), (0, jsx_runtime_1.jsx)("div", { children: "Add an individual event, or import a full schedule below." })] }));
        };
        return ((0, jsx_runtime_1.jsx)(jsx_runtime_1.Fragment, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-flex-direction-row oj-sm-12 orbr-content-container" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-flex oj-sm-flex-direction-column oj-sm-4 oj-sm-margin-2x-left orbr-event-panel" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-align-items-center" }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-flex oj-flex-item oj-icon orbr-tag-icon oj-sm-align-items-centre", title: "Tag Heuer logo", alt: "Tag Heuer logo" }) })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center oj-typography-heading-md orbr-event-container" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-label" }, { children: "COUNTDOWN TO:" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-hero-label" }, { children: name })), (0, jsx_runtime_1.jsx)(index_1.Counter, { targetTime: eventTime, autoLoad: autoLoad, loadNext: loadNextScheduleItem }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-flex-items-initial oj-sm-align-items-center orbr-time-text-hero-label" }, { children: (0, jsx_runtime_1.jsx)(index_2.Time, { localTime: timeNow }) }))] }))] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-item oj-sm-9" }, { children: [(0, jsx_runtime_1.jsx)("div", { class: "oj-flex orbr-video-container" }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-typography-subheading-md oj-flex-bar oj-color-invert footer" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar-end" }, { children: [(0, jsx_runtime_1.jsx)("span", Object.assign({ class: "o-text" }, { children: "POWERED BY" })), (0, jsx_runtime_1.jsx)("button", Object.assign({ class: "addbtn2", onClick: open }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-icon orbr-oracle-icon", title: "oracle logo", alt: "Oracle logo" }) }))] })) }))] })), (0, jsx_runtime_1.jsx)("span", { children: (0, jsx_runtime_1.jsx)("oj-drawer-popup", Object.assign({ class: "orbr-drawer-end", edge: "end", opened: endOpened, autoDismiss: "none" }, { children: (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "orbr-drawer-container" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar orbr-drawer-header" }, { children: [(0, jsx_runtime_1.jsx)("h6", Object.assign({ class: "oj-flex-bar-start" }, { children: "Event Settings" })), (0, jsx_runtime_1.jsxs)("oj-button", Object.assign({ id: "endButtonCloser", display: "icons", chroming: "borderless", class: "oj-flex-bar-end", onojAction: endToggle }, { children: [(0, jsx_runtime_1.jsx)("span", { slot: "startIcon", class: "oj-ux-ico-close orbr-drawer-text-color" }), "Close"] }))] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "orbr-drawer-content" }, { children: [(0, jsx_runtime_1.jsxs)("oj-form-layout", { children: [(0, jsx_runtime_1.jsx)("oj-switch", { labelHint: "Use browser locale", labelEdge: "inside", value: locale, onvalueChanged: updateLocale }), (0, jsx_runtime_1.jsx)("oj-switch", { labelHint: "Auto-load schedule", labelEdge: "inside", value: autoLoad, onvalueChanged: updateAutoLoad })] }), (0, jsx_runtime_1.jsx)("h4", { children: "Select active event" }), (0, jsx_runtime_1.jsxs)("oj-list-view", Object.assign({ data: eventDP.current, selectionMode: "single", gridlines: { item: "visibleExceptLast" }, selected: selectedEvent, onselectedChanged: selectedChangedHandler, class: "orbr-listview-sizing" }, { children: [(0, jsx_runtime_1.jsx)("template", { slot: "itemTemplate", render: listItemTemplate }), (0, jsx_runtime_1.jsx)("template", { slot: "noData", render: noDataTemplate })] })), (0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ class: "oj-sm-margin-4x-top" }, { children: [(0, jsx_runtime_1.jsx)("h4", { children: "Add new event" }), (0, jsx_runtime_1.jsx)("oj-input-text", { labelHint: "Name", value: eventNameVal, clearIcon: "conditional", help: { instruction: "All event names must be unique" }, onvalueChanged: updateNameVal }), (0, jsx_runtime_1.jsx)("oj-input-text", { labelHint: "Start time", placeholder: "YYYY-MM-DD HH:MM:SS", help: {
                                                            instruction: "Required format YYYY-MM-DD<space>HH:MM:SS with one space.",
                                                        }, value: startTimeVal, clearIcon: "conditional", onvalueChanged: updateStartTimeVal }), (0, jsx_runtime_1.jsx)("oj-button", { onojAction: addEvent, label: "Add event" })] })), (0, jsx_runtime_1.jsxs)("oj-form-layout", Object.assign({ class: "oj-sm-margin-4x-top" }, { children: [(0, jsx_runtime_1.jsx)("h4", { children: "Import event schedule" }), (0, jsx_runtime_1.jsx)("oj-text-area", { rows: 10, labelHint: "Schedule", placeholder: '[ {"name": "My event", "startTime":"2023-03-19 14:15:00"} ]', value: scheduleValue, help: {
                                                            instruction: 'paste array of objects in the format of {"name":"my event", "startTime":"YYYY-MM-DD<space>HH:MM:SS"}',
                                                        }, onvalueChanged: updateScheduleVal }), (0, jsx_runtime_1.jsx)("oj-button", { onojAction: importSchedule, label: "Import" })] }))] }))] })) })) })] })) }));
    }
    exports.Content = Content;
});
