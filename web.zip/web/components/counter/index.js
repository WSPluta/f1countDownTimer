define(["require", "exports", "preact/jsx-runtime", "preact/hooks"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Counter = void 0;
    const getTimeRemaining = (targetTime) => {
        const total = Date.parse(targetTime) - Date.parse(new Date().toISOString());
        if (total < 0) {
            return {
                total: 0,
                days: "00",
                hours: "00",
                minutes: "00",
                seconds: "00",
            };
        }
        const seconds = Math.floor((total / 1000) % 60).toString();
        const minutes = Math.floor((total / 1000 / 60) % 60).toString();
        const hours = Math.floor((total / (1000 * 60 * 60)) % 24).toString();
        const days = Math.floor(total / (1000 * 60 * 60 * 24)).toString();
        return {
            total,
            days,
            hours,
            minutes,
            seconds,
        };
    };
    function Counter(props) {
        const initClock = (0, hooks_1.useMemo)(() => {
            return getTimeRemaining(props.targetTime);
        }, [props.targetTime]);
        const [hours, setHours] = (0, hooks_1.useState)(initClock.hours.padStart(2, "0"));
        const [minutes, setMinutes] = (0, hooks_1.useState)(initClock.minutes.padStart(2, "0"));
        const [seconds, setSeconds] = (0, hooks_1.useState)(initClock.seconds.padStart(2, "0"));
        (0, hooks_1.useEffect)(() => {
            const timeinterval = setInterval(() => {
                const t = getTimeRemaining(props.targetTime);
                setHours(t.hours.padStart(2, "0"));
                setMinutes(t.minutes.padStart(2, "0"));
                setSeconds(t.seconds.padStart(2, "0"));
                if (t.total <= 0) {
                    clearInterval(timeinterval);
                    setHours("00");
                    setMinutes("00");
                    setSeconds("00");
                    if (props.autoLoad) {
                        props.loadNext();
                    }
                }
            }, 1000);
            return () => {
                clearInterval(timeinterval);
            };
        }, [props.targetTime, props.autoLoad]);
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-typography-heading-2xl oj-sm-align-items-center oj-sm-justify-content-center" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-sm-justify-content-center orbr-counter-text" }, { children: [hours, " : ", minutes, " : ", seconds] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex-bar oj-sm-justify-content-center orbr-counter-label" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-start", style: "margin-left: 24px;" }, { children: "HR" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-middle oj-sm-justify-content-center" }, { children: "MIN" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-bar-end", style: "margin-right: 24px;" }, { children: "SEC" }))] }))] })));
    }
    exports.Counter = Counter;
});
