define(["require", "exports", "preact/jsx-runtime", "preact/hooks"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Counter = void 0;
    const getTimeRemaining = (targetTime, currentTime) => {
        const total = Date.parse(targetTime) - Date.parse(new Date(currentTime).toISOString());
        if (total < 0) {
            return {
                total: 0,
                days: "00",
                hours: "00",
                minutes: "00",
                seconds: "00",
            };
        }
        const seconds = Math.floor((total / 1000) % 60).toString();
        const minutes = Math.floor((total / 1000 / 60) % 60).toString();
        const hours = Math.floor((total / (1000 * 60 * 60)) % 24).toString();
        const days = Math.floor(total / (1000 * 60 * 60 * 24)).toString();
        return {
            total,
            days,
            hours,
            minutes,
            seconds,
        };
    };
    function Counter(props) {
        const [hours, setHours] = (0, hooks_1.useState)(null);
        const [minutes, setMinutes] = (0, hooks_1.useState)(null);
        const [seconds, setSeconds] = (0, hooks_1.useState)(null);
        (0, hooks_1.useEffect)(() => {
            if (props.currentTime) {
                const t = getTimeRemaining(props.targetTime, props.currentTime);
                setHours(t.hours.padStart(2, "0"));
                setMinutes(t.minutes.padStart(2, "0"));
                setSeconds(t.seconds.padStart(2, "0"));
                if (t.total <= 0) {
                    setHours("00");
                    setMinutes("00");
                    setSeconds("00");
                    if (props.autoLoad) {
                        props.loadNext();
                    }
                }
            }
        }, [props.targetTime, props.autoLoad, props.currentTime]);
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-typography-heading-2xl oj-sm-align-items-center oj-sm-justify-content-center" }, { children: [(0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-12 oj-sm-justify-content-center" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-text" }, { children: hours })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-1 oj-sm-align-items-center orbr-counter-text-colon" }, { children: ":" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-text" }, { children: minutes })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-1 oj-sm-align-items-center orbr-counter-text-colon" }, { children: ":" })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-text" }, { children: seconds }))] })), (0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-12 oj-sm-justify-content-center" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-label" }, { children: "HR" })), (0, jsx_runtime_1.jsx)("div", { class: "oj-flex-item oj-sm-1 oj-sm-align-items-center orbr-counter-text" }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-label" }, { children: "MIN" })), (0, jsx_runtime_1.jsx)("div", { class: "oj-flex-item oj-sm-1 oj-sm-align-items-center orbr-counter-label" }), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item oj-sm-3 oj-sm-align-items-center orbr-counter-label" }, { children: "SEC" }))] }))] })));
    }
    exports.Counter = Counter;
});
