define(["require", "exports", "preact/jsx-runtime", "preact/hooks"], function (require, exports, jsx_runtime_1, hooks_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Time = void 0;
    function Time(props) {
        const [time, setTime] = (0, hooks_1.useState)(Date.now());
        const formatDate = (data, timezone) => {
            let dateObj = new Date(data);
            let options = {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                timeZone: timezone,
                hour12: false,
            };
            return dateObj.toLocaleTimeString(navigator.language, options);
        };
        (0, hooks_1.useEffect)(() => {
            let timer = setInterval(() => setTime(Date.now()), 1000);
            return () => clearInterval(timer);
        }, []);
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-flex-direction-column oj-typography-subheading-xl oj-sm-align-items-start orbr-time-text" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex" }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-flex oj-flex-item oj-icon oj-sm-align-items-centre orbr-line-icon", title: "line", alt: "lineBreak" }) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: (0, jsx_runtime_1.jsxs)("span", Object.assign({ class: "orbr-time-text-label2" }, { children: [" LOCAL TIME:", " ", " "] })) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: (0, jsx_runtime_1.jsxs)("span", Object.assign({ class: "orbr-time-text-clock" }, { children: [formatDate(time, Intl.DateTimeFormat().resolvedOptions().timeZone), " "] })) }))] })));
    }
    exports.Time = Time;
});
