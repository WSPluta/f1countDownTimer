define(["require", "exports", "preact/jsx-runtime"], function (require, exports, jsx_runtime_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.Time = void 0;
    function Time(props) {
        const formatDate = (time, timezone) => {
            const sec = time.getSeconds();
            let dateObj = new Date(time);
            let options = {
                hour: "2-digit",
                minute: "2-digit",
                second: "2-digit",
                timeZone: timezone,
                hour12: false,
            };
            dateObj.setSeconds(dateObj.getSeconds() + 1);
            return dateObj.toLocaleTimeString(navigator.language, options);
        };
        return ((0, jsx_runtime_1.jsxs)("div", Object.assign({ class: "oj-flex oj-sm-flex-direction-column oj-typography-subheading-xl oj-sm-align-items-start orbr-time-text" }, { children: [(0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex" }, { children: (0, jsx_runtime_1.jsx)("div", { role: "img", class: "oj-flex oj-flex-item oj-icon oj-sm-align-items-centre orbr-line-icon", title: "line", alt: "lineBreak" }) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: (0, jsx_runtime_1.jsx)("span", Object.assign({ class: "orbr-time-text-label2" }, { children: " LOCAL TIME: " })) })), (0, jsx_runtime_1.jsx)("div", Object.assign({ class: "oj-flex-item" }, { children: (0, jsx_runtime_1.jsx)("span", Object.assign({ class: "orbr-time-text-clock" }, { children: formatDate(props.localTime, Intl.DateTimeFormat().resolvedOptions().timeZone) })) }))] })));
    }
    exports.Time = Time;
});
